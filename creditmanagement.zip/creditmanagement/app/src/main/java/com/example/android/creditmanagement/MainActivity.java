package com.example.android.creditmanagement;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

class User {
    String name;
    String email;
    int creditIndex;
}

public class MainActivity extends AppCompatActivity {
    Button button;
    static SQLiteDatabase myDatabase;
    static ArrayList<User> users = new ArrayList<>();
    static ArrayList<String>  transactions = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView=(ListView) findViewById(R.id.listView);

        final ArrayList<String> arrayList=new ArrayList<String>();

        arrayList.add("User-1");
        arrayList.add("User-2");
        arrayList.add("User-3");
        arrayList.add("User-4");
        arrayList.add("User-5");
        arrayList.add("User-6");
        arrayList.add("User-7");
        arrayList.add("User-8");
        arrayList.add("User-9");
        arrayList.add("User-10");

        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrayList);

        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent =new Intent(getApplicationContext(),UserDisplay.class);
                intent.putExtra("userId",i);
                startActivity(intent);

            }
        });


        try{

             myDatabase = this.openOrCreateDatabase("Users",MODE_PRIVATE,null);

            myDatabase.execSQL("CREATE TABLE IF NOT EXISTS users (name VARCHAR,email VARCHAR,credit INTEGER(10),id INTEGER PRIMARY KEY)");

//            myDatabase.execSQL("INSERT INTO users (name,email,credit) VALUES ('User1','user1@gmail.com',100)");
//
//            myDatabase.execSQL("INSERT INTO users (name,email,credit) VALUES ('User2','user2@gmail.com',150)");
//
//            myDatabase.execSQL("INSERT INTO users (name,email,credit) VALUES ('User3','user3@gmail.com',300)");
//
//            myDatabase.execSQL("INSERT INTO users (name,email,credit) VALUES ('User4','user4@gmail.com',50)");
//
//            myDatabase.execSQL("INSERT INTO users (name,email,credit) VALUES ('User5','user5@gmail.com',200)");
//
//            myDatabase.execSQL("INSERT INTO users (name,email,credit) VALUES ('User6','user6@gmail.com',350)");
//
//            myDatabase.execSQL("INSERT INTO users (name,email,credit) VALUES ('User7','user7@gmail.com',400)");
//
//            myDatabase.execSQL("INSERT INTO users (name,email,credit) VALUES ('User8','user8@gmail.com',250)");
//
//            myDatabase.execSQL("INSERT INTO users (name,email,credit) VALUES ('User9','user9@gmail.com',450)");
//
//            myDatabase.execSQL("INSERT INTO users (name,email,credit) VALUES ('User10','user10@gmail.com',500)");
//
            // myDatabase.execSQL("DELETE FROM " + "users" );

            myDatabase.execSQL("CREATE TABLE IF NOT EXISTS transfers (transferLog VARCHAR)");

            Cursor c = myDatabase.rawQuery("SELECT * FROM users",null);

            Cursor cursor = myDatabase.rawQuery("SELECT * FROM transfers",null);

            int nameIndex = c.getColumnIndex("name");
            int emailIndex = c.getColumnIndex("email");
            int creditIndex = c.getColumnIndex("credit");
            int idIndex = c.getColumnIndex("id");
            int trans = cursor.getColumnIndex("transferLog");
//            if(c.moveToFirst()){
//                for (int j=0;j<c.getCount();++j)
//                {
//
//                    Log.e("name",c.getString(nameIndex));
//                    Log.e("email",c.getString(emailIndex));
//                    Log.e("credit", Integer.toString(c.getInt(creditIndex)));
//                    Log.e("id",Integer.toString(c.getInt(idIndex)));
//                    c.moveToNext();
//                }
//            }

            if(c.moveToFirst()){
                do{
                    User temp=new User();
                    temp.name=c.getString(nameIndex);
                    temp.email=c.getString(emailIndex);
                    temp.creditIndex=c.getInt(creditIndex);
                    users.add(temp);
                }while(c.moveToNext());
            }

            if (cursor.moveToFirst()){
                do {
                   transactions.add(cursor.getString(trans));
                }while (cursor.moveToNext());
            }


        }

        catch (Exception e){
            //Log.e("ERROR",e.getMessage());
            e.printStackTrace();
        }

        button = (Button) findViewById(R.id.historybutton);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Transaction.class);
                startActivity(intent);
            }
        });

    }
}
