package com.example.android.creditmanagement;

import android.database.sqlite.SQLiteStatement;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.database.sqlite.SQLiteDatabase;

import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import static com.example.android.creditmanagement.CustomOnItemSelectedListener.rec_user;
import static com.example.android.creditmanagement.MainActivity.myDatabase;
import static com.example.android.creditmanagement.MainActivity.transactions;
import static com.example.android.creditmanagement.MainActivity.users;

public class UserDisplay extends AppCompatActivity {
    EditText editText;
    private Spinner spinner;
  int i,n;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_display);

        String index =  getIntent().getExtras().get("userId").toString();
         i = Integer.parseInt(index);
        //Log.e("name",   Integer.toString(i));

        TextView textView =(TextView) findViewById(R.id.name);
        textView.setText(users.get(i).name);

        TextView textView2 =(TextView) findViewById(R.id.email);
        textView2.setText(users.get(i).email);

        TextView textView1 =  (TextView) findViewById(R.id.credit);
        textView1.setText(Integer.toString(users.get(i).creditIndex));

        addItemsOnSpinner2();
        addListenerOnSpinnerItemSelection();
        //addListenerOnButton();

        editText =(EditText) findViewById(R.id.number);
        editText.addTextChangedListener(new TextWatcher(){

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if(!(String.valueOf(editText.getText()).equals(""))){
                    n=Integer.parseInt(String.valueOf(editText.getText()));
                }
                Log.e("creditvalue",editText.getText().toString());

            }

            @Override
            public void afterTextChanged(Editable s) {


            }
        });


    }

    //add items into spinner dynamically
    public void addItemsOnSpinner2() {

        spinner = (Spinner) findViewById(R.id.spinner);
        List<String> list = new ArrayList<String>();
        list.add("      User1");
        list.add("      User2");
        list.add("      User3");
        list.add("      User4");
        list.add("      User5");
        list.add("      User6");
        list.add("      User7");
        list.add("      User8");
        list.add("      User9");
        list.add("      User10");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
    }

//    get the selected dropdown list value
//    public void addListenerOnButton() {
//
//        spinner2 = (Spinner) findViewById(R.id.spinner2);
//
//    }

    public void addListenerOnSpinnerItemSelection(){

        spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new CustomOnItemSelectedListener());

    }

    public void transfer(View view){
        User tempo= new User();
        tempo.name = users.get(rec_user).name;
        tempo.creditIndex = users.get(rec_user).creditIndex + n;
        tempo.email = users.get(rec_user).email;
        users.set(rec_user,tempo);

        User tempo1 = new User();
        tempo1.name = users.get(i).name;
        tempo1.creditIndex = users.get(i).creditIndex - n;
        tempo1.email = users.get(i).email;
        users.set(i,tempo1);

        String trans = users.get(i).name + " transfered " + n + " credits to " + users.get(rec_user).name ;
        transactions.add(trans);
        String sql="INSERT INTO transfers(transferLog) VALUES (?)";

        SQLiteStatement statement=myDatabase.compileStatement(sql);

        statement.bindString(1,trans);
        statement.execute();

    }

    }